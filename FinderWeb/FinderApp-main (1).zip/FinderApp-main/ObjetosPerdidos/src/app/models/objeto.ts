export interface Objeto {
    titulo:string;
    descripcion:string;
    ubicacion:string;
    fecha_encontrado:string;
    imagen:string;
}