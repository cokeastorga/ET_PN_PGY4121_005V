export const environment = {
  production: true
};

export const firebaseConfig = {
  apiKey: "AIzaSyBlyNNeP35CwnX6aVOPkXvKZgfplABFEAQ",
  authDomain: "objetosperdidos-54c6f.firebaseapp.com",
  projectId: "objetosperdidos-54c6f",
  storageBucket: "objetosperdidos-54c6f.appspot.com",
  messagingSenderId: "217039724142",
  appId: "1:217039724142:web:07a5179c5025eb89d0107f"
}
