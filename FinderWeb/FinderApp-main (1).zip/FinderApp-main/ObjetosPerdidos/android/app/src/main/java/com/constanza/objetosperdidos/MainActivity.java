package com.constanza.objetosperdidos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
